package revisions;

/**
 * Created by bidyut on 2/9/17.
 */
public enum TaskState {
    STARTED, RUNNING, COMPLETED, EXITED
}
