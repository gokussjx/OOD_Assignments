/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bm346checkers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author bidyut
 */
public class CheckersFXMLController implements Initializable {

    @FXML
    private VBox vBox;

    @FXML
    private MenuBar menuBar;

    @FXML
    private AnchorPane anchorPane;

    private int numRows = 8;
    private int numCols = 8;

    private boolean defaultColor = true;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    public void ready(Stage stage) {

        // Render with every change in stage size
        ChangeListener<Number> listener = (observable, oldValue, newValue) -> render();

        stage.widthProperty().addListener(listener);
        stage.heightProperty().addListener(listener);

        render();
    }

    public void render() {
        // Clear the vBox first
        vBox.getChildren().remove(anchorPane);

        // Get future checkerboard width and height
        double boardWidth = vBox.getWidth();
        double boardHeight = vBox.getHeight() - menuBar.getHeight();

        // Initialize and get the checkerboard
        CheckerBoard checkerBoard = defaultColor ?
                new CheckerBoard(numRows, numCols, boardWidth, boardHeight) :
                new CheckerBoard(numRows, numCols, boardWidth, boardHeight, Color.SKYBLUE, Color.DARKBLUE);
        try {
            anchorPane = checkerBoard.build();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }

        // Add new checkerboard AnchorPane to root VBox
        vBox.getChildren().add(anchorPane);
    }

    @FXML
    public void changeGridSize(ActionEvent event) {
        // Identify the source menu item
        MenuItem item = (MenuItem) event.getSource();
        String itemId = item.getId();

        switch (itemId) {
            case "sixteen":
                numRows = numCols = 16;
                break;
            case "ten":
                numRows = numCols = 10;
                break;
            case "eight":
                numRows = numCols = 8;
                break;
            case "three":
                numRows = numCols = 3;
                break;
            default:
                numRows = numCols = 8;
                break;
        }

        render();
    }

    @FXML
    public void changeColorScheme(ActionEvent event) {
        // Identify the source menu item
        MenuItem item = (MenuItem) event.getSource();
        String itemId = item.getId();

        switch (itemId) {
            case "default":
                defaultColor = true;
                break;
            case "blue":
                defaultColor = false;
                break;
            default:
                defaultColor = true;
                break;
        }

        render();
    }
    
}
